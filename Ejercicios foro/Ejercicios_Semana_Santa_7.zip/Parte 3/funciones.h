#include <stdio.h>
#include <stdlib.h>

struct estudiante{
	char nombre[50];
	int dni;
	float nota;
};


struct estudiante *reservamemoria(int tam);
void rellenavector(struct estudiante *v, int tam);
void imprimevector(struct estudiante *v, int tam);
int calculamedia(struct estudiante *v, int tam);
void liberamemoria(struct estudiante *v);
