#include "funciones.h"

struct estudiante *reservamemoria(int tam){

	struct estudiante *aux=NULL;

	aux=(struct estudiante*)malloc(sizeof(struct estudiante)*tam);
	if(aux==NULL){
		printf("Error al reservar memoria\n");
		exit(-1);
	}

 return aux;
}






void rellenavector(struct estudiante *v, int tam){

	int i;

	for(i=0;i<tam;i++){
	   printf("\n\nESTUDIANTE Nº %d\n",i+1);
		getchar();
		printf("Introduce el nombre: ");
		fgets(v[i].nombre,50,stdin);

		printf("Introduce DNI(sin letra): ");
		scanf("%d",&v[i].dni);

		printf("Introduce la nota: ");
		scanf("%f",&v[i].nota);
	}
}





void imprimevector(struct estudiante *v, int tam){

	int i;

	printf("IMPRIMIENDO VECTOR...\n");
	for(i=0;i<tam;i++){
		printf("ESTUDIANTE Nº %d\n",i+1);
		printf("Nombre: %s, DNI: %d, Nota: %f\n",v[i].nombre,v[i].dni,v[i].nota);
	}
}






int calculamedia(struct estudiante *v, int tam){

	int i;
	float contador=0;

	for(i=0;i<tam;i++){
		contador=contador+strlen(v[i].nombre)-1;
	}

 contador=contador/tam;

return contador;
}




void liberamemoria(struct estudiante *v){
	free(v);
}
