#include "funciones.h"

int main (){

	struct estudiante *v;
	int tam;
	float media=0;

	printf("Introduce el tamaño del vector: ");
	scanf("%d",&tam);

	v=reservamemoria(tam);
	rellenavector(v,tam);
	imprimevector(v,tam);
	media=calculamedia(v,tam);
	printf("La longitud media es: %f\n",media);
	liberamemoria(v);
}
