#include "entradaSalida.h"

void rellenavector(int *v,int tam){

	int i;

	for(i=0;i<tam;i++){
		printf("Introduce el elemento v[%d]: ",i);
		scanf("%d",&v[i]);
	}
}
