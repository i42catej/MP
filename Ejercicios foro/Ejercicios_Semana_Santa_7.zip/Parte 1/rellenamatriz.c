#include "entradaSalida.h"

void rellenamatriz(int **m,int nfil,int ncol){

	int i,j;
	
	for(i=0;i<nfil;i++){
		for(j=0;j<ncol;j++){
			printf("M[%d][%d]: ",i,j);
			scanf("%d",&m[i][j]);
		}
	}
}
