#include "entradaSalida.h"

void muestravector(int *v,int tam){

	int i;
	
	printf("Mostrando vector...\n");
	for(i=0;i<tam;i++){
		printf("[%d] ",v[i]);
	}
	printf("\n");
}
