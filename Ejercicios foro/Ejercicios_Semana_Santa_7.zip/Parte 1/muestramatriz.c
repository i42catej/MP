#include "entradaSalida.h"

void muestramatriz(int **m,int nfil,int ncol){

	int i,j;

	for(i=0;i<nfil;i++){
		for(j=0;j<ncol;j++){
			printf("%d ",m[i][j]);
		}
	   printf("\n");
	}

}
