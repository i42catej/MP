#include <stdio.h>
#include <stdlib.h>

int **reservamemoriamatriz(int nfil, int ncol);
int *reservamemoriavector(int tam);
int *extraervector(int **m,int nfil,int ncol,int num,int *tamV);
void calculamaxmin(int **m,int nfil,int ncol, int *max, int *min);
void liberamatriz(int **m,int nfil);
void liberavector(int *v);
