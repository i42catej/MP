#include "funciones.h"

int **reservamemoriamatriz(int nfil, int ncol){

	int **m=NULL;

	m=(int**)malloc(sizeof(int*)*nfil);
	if(m==NULL){
		printf("Error al reservar memoria\n");
		exit(-1);
	}

	int i;
	for(i=0;i<nfil;i++){
		m[i]=(int*)malloc(sizeof(int)*ncol);

		if(m[i]==NULL){
			printf("Error al reservar memoria\n");
			exit(-1);
		}
	}
 return m;
}


int *reservamemoriavector(int tam){

	int *v=NULL;

	v=(int*)malloc(sizeof(int)*tam);
	if(v==NULL){
		printf("Error de reserva en el vector\n");
		exit(-1);
	}
   return v;
}

/**
	@fn int *extraervector(int **m,int nfil,int ncol,int num,int *tamV)
	@brief Extrae los numeros de la matriz mayores que "num"
	@param **m Matriz
	@param nFil Numero de filas
	@param nCol Numero de columnas
	@param num Numero para saber cuales extraer
	@param *tamV Tamaño del vector con los numeros mayores que "num"
	@pre Matriz debe de tener numeros
	@post Se debe de haber reservado memoria para el vector
	@return aux
	
*/


int *extraervector(int **m,int nfil,int ncol,int num,int *tamV){

	int i,j;
		for(i=0;i<nfil;i++){
			for(j=0;j<ncol;j++){
				if(m[i][j]>num){
					(*tamV)++;
				}
			}
		}

		int *aux;
		aux=reservamemoriavector((*tamV));

	int cont=0;

		for(i=0;i<nfil;i++){
			for(j=0;j<ncol;j++){
				if(m[i][j]>num){
					aux[cont]=m[i][j];
					cont++;
				}
			}
		}
return aux;

}

/**

	@fn void calculamaxmin(int **m,int nfil,int ncol, int *max, int *min)
	@brief Calcula el maximo y minimo de la matriz
	@param **m Matriz
	@param nfil Numero de filas 
	@param ncol Numero de columnas
	@param *max El maximo pasado por referencia
	@param *min El minimo pasado por referencia
	@pre Matriz debe de tener numeros 
	

*/

void calculamaxmin(int **m,int nfil,int ncol, int *max, int *min){

	int i,j;
		
	for(i=0;i<nfil;i++){
		for(j=0;j<ncol;j++){

			if(m[i][j]<(*min)){
				(*min)=m[i][j];
			}
			
			if(m[i][j]>(*max)){
				(*max)=m[i][j];
			}				
		}
	}
}






void liberamatriz(int **m,int nfil){

	int i;

	for(i=0;i<nfil;i++){
		free(m[i]);
	}

	free(m);
}




void liberavector(int *v){

	free(v);
}
