#include <stdio.h>
#include <stdlib.h>

void rellenavector(int *v,int tam);
void muestravector(int *v,int tam);
void rellenamatriz(int **m,int nfil,int ncol);
void muestramatriz(int **m,int nfil,int ncol);
