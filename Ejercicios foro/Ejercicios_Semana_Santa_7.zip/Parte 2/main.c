#include "funciones.h"
#include "entradaSalida.h"

int main(){
	
	int **ma=NULL;
	int nfil,ncol,numero,tamAux=0;
	int *ve=NULL;
	int maximo=0,minimo=1000;
	
	printf("Introduzca el numero de filas: ");
	scanf("%d",&nfil);
	printf("Introduzca el numero de columnas: ");
	scanf("%d",&ncol);

	ma=reservamemoriamatriz(nfil,ncol);
	rellenamatriz(ma,nfil,ncol);
	muestramatriz(ma,nfil,ncol);

	printf("Introduzca el numero para extraer los mayores que el: ");
	scanf("%d",&numero);

	ve=extraervector(ma,nfil,ncol,numero,&tamAux);
	muestravector(ve,tamAux);


	calculamaxmin(ma,nfil,ncol,&maximo,&minimo);
	printf("Maximo: %d 	Minimo: %d\n",maximo,minimo);


	liberamatriz(ma,nfil);
	liberavector(ve);
 return 0;
}
